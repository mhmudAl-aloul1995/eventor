<a href="https://1.envato.market/materialize_admin" target="_blank"
  class="btn btn-buy-now gradient-45deg-indigo-purple gradient-shadow white-text tooltipped buy-now-animated tada"
  data-position="left" data-tooltip="Buy Now!"><i class="material-icons">add_shopping_cart</i>
</a><?php /**PATH /Users/vrushank/Downloads/materialize-admin/full-version/resources/views/pages/partials/buy-now.blade.php ENDPATH**/ ?>