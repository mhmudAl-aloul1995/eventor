<!-- BEGIN VENDOR JS-->
<script src="<?php echo e(asset('js/vendors.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/jquery-validation/jquery.validate.min.js')); ?>"></script>

<!-- BEGIN VENDOR JS-->
<!-- BEGIN PAGE VENDOR JS-->
<?php echo $__env->yieldContent('vendor-script'); ?>
<!-- END PAGE VENDOR JS-->
<!-- BEGIN THEME  JS-->
<script src="<?php echo e(asset('vendors/select2/select2.full.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendors/data-tables/extensions/responsive/js/dataTables.responsive.min.js')); ?>"></script>

<script src="<?php echo e(asset('js/plugins.js')); ?>"></script>
<script src="<?php echo e(asset('js/search.js')); ?>"></script>

<script src="<?php echo e(asset('js/custom/custom-script.js')); ?>"></script>
<?php if($configData['isCustomizer']=== true): ?>
<script src="<?php echo e(asset('js/scripts/customizer.js')); ?>"></script>
<?php endif; ?>


<!-- END THEME  JS-->
<!-- BEGIN PAGE LEVEL JS-->
<script>

    var links ='<?php echo e(url('')); ?>';
    var token='<?php echo e(csrf_token()); ?>'
</script>
<?php echo $__env->yieldContent('page-script'); ?><?php /**PATH C:\xampp\htdocs\eventor\resources\views/panels/scripts.blade.php ENDPATH**/ ?>