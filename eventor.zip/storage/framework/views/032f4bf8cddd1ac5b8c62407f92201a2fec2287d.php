<!-- Intro -->
<div id="intro">
  <div class="row">
    <div class="col s12">

      <div id="img-modal" class="modal white">
        <div class="modal-content">
          <div class="bg-img-div"></div>
          <p class="modal-header right modal-close">
            Skip Intro <span class="right"><i class="material-icons right-align">clear</i></span>
          </p>
          <div class="carousel carousel-slider center intro-carousel">
            <div class="carousel-fixed-item center middle-indicator">
              <div class="left">
                <button
                  class="movePrevCarousel middle-indicator-text btn btn-flat purple-text waves-effect waves-light btn-prev">
                  <i class="material-icons">navigate_before</i> <span class="hide-on-small-only">Prev</span>
                </button>
              </div>

              <div class="right">
                <button
                  class=" moveNextCarousel middle-indicator-text btn btn-flat purple-text waves-effect waves-light btn-next">
                  <span class="hide-on-small-only">Next</span> <i class="material-icons">navigate_next</i>
                </button>
              </div>
            </div>
            <div class="carousel-item slide-1">
              <img src="<?php echo e(asset('images/gallery/intro-slide-1.png')); ?>" alt=""
                class="responsive-img animated fadeInUp slide-1-img">
              <h5 class="intro-step-title mt-7 center animated fadeInUp">Welcome to Materialize</h5>
              <p class="intro-step-text mt-5 animated fadeInUp">Materialize is a Material Design Admin
                Template is the excellent responsive google material design inspired multipurpose admin
                template. Materialize has a huge collection of material design animation & widgets, UI
                Elements.</p>
            </div>
            <div class="carousel-item slide-2">
              <img src="<?php echo e(asset('images/gallery/intro-features.png')); ?>" alt="" class="responsive-img slide-2-img">
              <h5 class="intro-step-title mt-7 center">Example Request Information</h5>
              <p class="intro-step-text mt-5">Lorem ipsum dolor sit amet consectetur,
                adipisicing elit.
                Aperiam deserunt nulla
                repudiandae odit quisquam incidunt, maxime explicabo.</p>
              <div class="row">
                <div class="col s6">
                  <div class="input-field">
                    <label for="first_name">Name</label>
                    <input placeholder="Name" id="first_name" type="text" class="validate">
                  </div>
                </div>
                <div class="col s6">
                  <div class="input-field">
                    <select>
                      <option value="" disabled selected>Choose your option</option>
                      <option value="1">Option 1</option>
                      <option value="2">Option 2</option>
                      <option value="3">Option 3</option>
                    </select>
                    <label>Materialize Select</label>
                  </div>
                </div>
              </div>
            </div>
            <div class="carousel-item slide-3">
              <img src="<?php echo e(asset('images/gallery/intro-app.png')); ?>" alt="" class="responsive-img slide-1-img">
              <h5 class="intro-step-title mt-7 center">Showcase App Features</h5>
              <div class="row">
                <div class="col m5 offset-m1 s12">
                  <ul class="feature-list left-align">
                    <li><i class="material-icons">check</i> Email Application</li>
                    <li><i class="material-icons">check</i> Chat Application</li>
                    <li><i class="material-icons">check</i> Todo Application</li>
                  </ul>
                </div>
                <div class="col m6 s12">
                  <ul class="feature-list left-align">
                    <li><i class="material-icons">check</i>Contacts Application</li>
                    <li><i class="material-icons">check</i>Full Calendar</li>
                    <li><i class="material-icons">check</i> Ecommerce Application</li>
                  </ul>
                </div>
                <div class="row">
                  <div class="col s12 center">
                    <button
                      class="get-started btn waves-effect waves-light gradient-45deg-purple-deep-orange mt-3 modal-close">Get
                      Started</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- / Intro --><?php /**PATH /Users/vrushank/Downloads/materialize-admin/full-version/resources/views/pages/intro.blade.php ENDPATH**/ ?>